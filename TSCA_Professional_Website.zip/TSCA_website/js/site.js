
// Frontend site scripts: contact form + load CMS content
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, getDocs, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyALS-lTTo4r0eMjiqqcfZayVVOPioRPmSg",
  authDomain: "admin-panel-551ff.firebaseapp.com",
  projectId: "admin-panel-551ff",
  storageBucket: "admin-panel-551ff.firebasestorage.app",
  messagingSenderId: "463544367054",
  appId: "1:463544367054:web:2324f1fb00e8076344d1d9f"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function loadPosts(){
  try{
    const snap = await getDocs(collection(db,'posts'));
    const container = document.getElementById('posts') || document.getElementById('events');
    if(!container) return;
    container.innerHTML='';
    snap.forEach(d=>{
      const data=d.data();
      const el=document.createElement('article');
      el.innerHTML=`<h3>${data.title}</h3><p>${data.excerpt || ''}</p>`;
      container.appendChild(el);
    });
  }catch(e){console.error(e)}
}

const contact = document.getElementById('contactForm');
if(contact){
  contact.addEventListener('submit', async (e)=>{
    e.preventDefault();
    try{
      await addDoc(collection(db,'contactMessages'),{
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        subject: document.getElementById('subject').value,
        message: document.getElementById('message').value,
        timestamp: serverTimestamp()
      });
      document.getElementById('status').textContent='Message sent — thank you!';
      contact.reset();
    }catch(err){document.getElementById('status').textContent='Error sending message.'}
  });
}

loadPosts();
