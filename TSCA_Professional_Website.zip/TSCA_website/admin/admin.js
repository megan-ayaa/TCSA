
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore, collection, getDocs, addDoc, serverTimestamp, deleteDoc, doc, setDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-storage.js";
import Chart from "https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js";

const firebaseConfig = {
  apiKey: "AIzaSyALS-lTTo4r0eMjiqqcfZayVVOPioRPmSg",
  authDomain: "admin-panel-551ff.firebaseapp.com",
  projectId: "admin-panel-551ff",
  storageBucket: "admin-panel-551ff.firebasestorage.app",
  messagingSenderId: "463544367054",
  appId: "1:463544367054:web:2324f1fb00e8076344d1d9f"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Simple protected flow: redirect to login if not authenticated
onAuthStateChanged(auth, user => {
  const path = location.pathname;
  if(!user && !path.endsWith('login.html') && !path.endsWith('register.html')){
    location.href = 'login.html';
  }
  if(user && path.endsWith('login.html')) location.href='dashboard.html';
});

// Login form
const loginForm = document.getElementById('login');
if(loginForm){
  loginForm.addEventListener('submit', async e=>{
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    try{
      await signInWithEmailAndPassword(auth, email, password);
    }catch(err){document.getElementById('status').textContent = 'Login failed';}
  });
}

// Register form (protected with secret)
const reg = document.getElementById('reg');
if(reg){
  reg.addEventListener('submit', async e=>{
    e.preventDefault();
    const secret = document.getElementById('secret').value;
    // change this secret before deploying! stored client-side for ease in this scaffold
    if(secret !== 'MAKE_ADMIN_SECRET') { document.getElementById('status').textContent='Wrong setup secret'; return; }
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    try{
      await createUserWithEmailAndPassword(auth, email, password);
      document.getElementById('status').textContent='Admin created';
    }catch(err){document.getElementById('status').textContent='Error creating admin';}
  });
}

// Dashboard stats + chart
async function loadStats(){
  const subs = await getDocs(collection(db,'newsletterSubscribers'));
  const msgs = await getDocs(collection(db,'contactMessages'));
  const posts = await getDocs(collection(db,'posts'));
  const statsEl = document.getElementById('stats');
  if(statsEl) statsEl.innerHTML = `<p>Total Subscribers: ${subs.size}</p><p>Total Messages: ${msgs.size}</p><p>Posts: ${posts.size}</p>`;
  // simple chart based on counts
  const ctx = document.getElementById('chart');
  if(ctx){
    new Chart(ctx,{type:'bar',data:{labels:['Subscribers','Messages','Posts'],datasets:[{label:'Counts',data:[subs.size,msgs.size,posts.size]}]}});
  }
}

// Subscribers page
async function loadSubscribers(){
  const ul = document.getElementById('list');
  if(!ul) return;
  ul.innerHTML='';
  const snap = await getDocs(collection(db,'newsletterSubscribers'));
  snap.forEach(d=>{
    const li = document.createElement('li');
    li.innerHTML = `<strong>${d.data().name||'—'}</strong> — ${d.data().email} <button data-id="${d.id}" class="del">Delete</button>`;
    ul.appendChild(li);
  });
  document.querySelectorAll('.del').forEach(b=>b.onclick = async ()=>{ await deleteDoc(doc(db,'newsletterSubscribers',b.dataset.id)); loadSubscribers(); });
}

// Messages page
async function loadMessages(){
  const ul = document.getElementById('list');
  if(!ul) return;
  ul.innerHTML='';
  const snap = await getDocs(collection(db,'contactMessages'));
  snap.forEach(d=>{
    const li = document.createElement('li');
    li.innerHTML = `<strong>${d.data().name||'—'}</strong> — ${d.data().subject||'—'} <button data-id="${d.id}" class="del">Delete</button><p>${d.data().message||''}</p>`;
    ul.appendChild(li);
  });
  document.querySelectorAll('.del').forEach(b=>b.onclick = async ()=>{ await deleteDoc(doc(db,'contactMessages',b.dataset.id)); loadMessages(); });
}

// CMS page
const postForm = document.getElementById('postForm');
if(postForm){
  postForm.addEventListener('submit', async e=>{
    e.preventDefault();
    await addDoc(collection(db,'posts'),{title:document.getElementById('title').value,excerpt:document.getElementById('excerpt').value,timestamp:serverTimestamp()});
    document.getElementById('posts').textContent='Post published.';
  });
}

// Load posts list for CMS
async function loadPostsList(){
  const ul = document.getElementById('posts');
  if(!ul) return;
  ul.innerHTML='';
  const snap = await getDocs(collection(db,'posts'));
  snap.forEach(d=>{ const li = document.createElement('li'); li.textContent = d.data().title; ul.appendChild(li); });
}

// Upload handler
const upBtn = document.getElementById('up');
if(upBtn){
  upBtn.onclick = async ()=>{
    const file = document.getElementById('file').files[0];
    if(!file){ document.getElementById('status').textContent='Choose a file'; return; }
    const r = ref(storage,'uploads/'+file.name);
    await uploadBytes(r,file);
    const url = await getDownloadURL(r);
    document.getElementById('status').textContent='Uploaded: '+url;
  };
}

// init loaders
loadStats();
loadSubscribers();
loadMessages();
loadPostsList();
